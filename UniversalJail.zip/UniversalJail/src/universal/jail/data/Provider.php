<?php namespace universal\jail\data;


use universal\jail\Manager;
use pocketmine\utils\Config;


class Provider
{
	const FILENAME_JAIL = 'jail.json';


	/**
	 * @var Manager
	 */
	private $main;

	/**
	 * @var Config
	 */
	private $jail_data;


	/**
	 * @param Manager $main
	 */
	function __construct( Manager $main )
	{
		$this->main       = $main;
		$this->jail_data = new Config($main->getDataFolder(). self::FILENAME_JAIL);

		$this->jail_data->reload();

		$list = $this->jail_data->getAll();
}
	function get( string $nick )
	{
		$nick = strtolower($nick);
		$data = $this->jail_data->get($nick);

		if( empty($data) )
		{
			$data = false;
		}
		return $data;
	}
	
	/**
	 * @param string @nick
	 * @return Reason
	 */
	 function getReason( string $nick )
	{
		$nick = strtolower($nick);
		$data = $this->jail_data->get($nick);
		if( empty($data) )
		{
			$data = false;
		}
		return $data["reason"];
	}
	
	 /**
	 * @param string @nick
	 * @return Time
	 */
	 function getTime( string $nick )
	{
		$nick = strtolower($nick);
		$data = $this->jail_data->get($nick);
		if( empty($data) )
		{
			$data = false;
		}
		$time = $data["time"] - time();
		return $time;
	}
	
	 /**
	 * @param string @nick
	 * @return Source
	 */
	 function getSource( string $nick )
	{
		$nick = strtolower($nick);
		$data = $this->jail_data->get($nick);
		if( empty($data) )
		{
			$data = false;
		}
		return $data["source"];
	}
	
	/**
	 * @param string @nick
	 */
	 function remove( string $nick )
	{
		$nick = strtolower($nick);
		$data = $this->jail_data->get($nick);
		if( empty($data) )
		{
			return false;
		}
		
		$this->jail_data->remove($nick);
		$this->jail_data->save(true);
		return true;
	}
	 
	/**
	 * @param  string $nick
	 * @param  string $time
	 * @param  int $reason
	 * @param  string $source
	 */
	function add( string $nick, int $time, string $reason, string $source )
	{
		$nick = strtolower($nick);
		$this->jail_data->remove($nick);
		$time = time() + $time;
		$data = [
		    "time" => $time,
		    "reason" => $reason,
		    "source" => $source
		    ];
			$this->jail_data->set($nick, $data);
		$this->jail_data->save(true);
	}
}//}