<?php namespace universal\jail\task;



use universal\jail\Manager;


use pocketmine\scheduler\Task;
use pocketmine\world\Position;


class PositionCheckTask extends Task
{
	/**
	 * @var Manager
	 */
	private $main;

	/**
	 * @param Manager $main
	 */
	function __construct( Manager $main )
	{
		$this->main = $main;

		$main->getScheduler()->scheduleRepeatingTask($this, 40);
	}

	function onRun( ): void
	{
		$main = $this->main;

		foreach( $main->getServer()->getOnlinePlayers() as $player )
		{
		    
		$nick   = $player->getName();
		$data   = $main->getProvider();
		$jail   = $data->get($nick);
		
		if( $jail )
		{
		$radius = Manager::JAIL_RADIUS;
		$center = Manager::JAIL_POS;
		$center = new Position($center[0], $center[1], $center[2], $player->getWorld());
		if( $player->getPosition()->distance($center) > $radius )
			{
			    $player->sendTip("§c> §fНЕЛЬЗЯ ПОКИДАТЬ ТЮРЬМУ! §c<");
				$main->teleport($player, $center);
			   }
	    	}
		}
	}
}