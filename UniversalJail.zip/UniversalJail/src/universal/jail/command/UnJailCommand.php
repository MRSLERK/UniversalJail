<?php namespace universal\jail\command;

use universal\jail\Manager;
use universal\jail\util\Declinator;
use universal\jail\object\Account;


use pocketmine\command\CommandSender;
use pocketmine\command\Command;

use pocketmine\permission\Permission;
use pocketmine\player\Player;


class UnJailCommand extends Command
{
	/**
	 * @var Manager
	 */
	private $main;

	/**
	 * @var int[]
	 */
	private $use_counter = [];
	/**
	 * @param Manager $main
	 * @param string  $name
	 * @param string  $description
	 */
	const NAME        = 'unjail';
	const DESCRIPTION = 'Освободить игрока с тюрьмы.';
	
	/**
	 * @override
	 *
	 * @param string $name
	 * @param string $description
	 */
	function __construct(Manager $main, string $name = self::NAME, string $description = self::DESCRIPTION )
	{
		parent::__construct($name, $description);
		$this->main = $main;
	}

	/**
	 * @param  CommandSender $sender
	 * @param  string        $label
	 * @param  string[]      $argument
	 *
	 * @return bool
	 */
	function execute( CommandSender $sender, string $label, array $argument )
	{
		$main = $this->getManager();
		$prefix = Manager::SERVER_NAME;
		if( $sender instanceof Player )
		{
			$name = $sender->getName();

			$manager = $main->getUniGroup();
			$level   = Manager::ACCESS_COMMAND_UNJAIL;

			if( !$manager->hasAccess($name, $level) )
			{
				$group = $manager->getGroup($level);

				$sender->sendMessage("§c< §f$prefix §c> Требуется доступ группы $group!");
				$sender->sendMessage("§c< /h §f- узнать подробнее.");
				return false;
			}
		}

		//////////////////////////////////////////////////

		if( count($argument) < 1 )
		{
			$sender->sendMessage("§e< §f/unjail <игрок>");
			return false;
		}

		$nick = array_shift($argument);

		if( strlen($nick) > 16 )
		{
			$sender->sendMessage("§c< §f$prefix §c> Никнейм не является действительным!");
			return false;
		}
		
		if( isset($name) and strtolower($nick) == strtolower($name) )
		{
			$sender->sendMessage("§c< §f$prefix §c> Вы не можете освободить сами себя!");
			return false;
		}


		//////////////////////////////////////////////////

		$jail = $main->getProvider()->get($nick);
		if(!$jail)
		{
			$sender->sendMessage("§c< §f$prefix §c> $nick не находится в тюрьме!");
			return false;
		}

		if( isset($name) and !$this->handleUse($name) )
		{
			$limit = Manager::LIMIT_COMMAND_UNJAIL;

			$sender->sendMessage("§c< §f$prefix §c> Количество использование команды ограничено!");
			$sender->sendMessage("§c< $limit §fдля Вашей группы.");
			return false;
		}


		$name    = $name ?? 'Сервер';
		$target = $main->getServer()->getPlayerExact($nick);
		$main->getProvider()->remove($nick);
		if( isset($target) )
		{
		    $pos    = $main->getLastPosition($target->getName(), true);
		if( !isset($pos) )
		{
			$target->sendTip("§c> §fПОСЛЕДНЯЯ ПОЗИЦИЯ НЕ НАЙДЕНА! §c");
			$pos = $main->getServer()->getWorldManager()->getDefaultWorld()->getSpawnLocation();
		}
		
		$main->teleport($target, $pos);
		
		    $target->sendMessage("§a< §f$prefix §a> $name выпустил вас!");
		}
		if( $sender instanceof Player )
		{
			$main->getServer()->broadcastMessage("§e< §f$prefix §e> $name выпустили(а) с тюрьмы игрока $nick!");
		}
		else
		{
			$sender->sendMessage("§a< §f$prefix §a> Игрок $nick освобожден!");
		}

		return true;
	}


	/**
	 * @param  string $nick
	 *
	 * @return bool
	 */
	private function handleUse( string $nick )
	{
		$nick = strtolower($nick);

		if( !isset($this->use_counter[$nick]) )
		{
			$this->use_counter[$nick] = 0;
		}

		$limit = Manager::LIMIT_COMMAND_UNJAIL;

		if( $this->use_counter[$nick]++ < $limit )
		{
			return true;
		}

		$level = Manager::ACCESS_IGNORE_LIMIT_COMMAND_UNJAIL;

		if( $this->getManager()->getUniGroup()->hasAccess($nick, $level) )
		{
			return true;
		}

		return false;
	}


	/**
	 * @return Manager
	 */
	private function getManager( )
	{
		return $this->main;
	}
}