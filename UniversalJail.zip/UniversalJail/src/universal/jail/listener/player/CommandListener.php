<?php namespace universal\jail\listener\player;
/*
* @author MRSLERK
*
* @link vk.com/ii.gor32
*/
use universal\jail\Manager;

use universal\jail\util\Declinator;
use pocketmine\event\player\PlayerCommandPreprocessEvent as Event;
use pocketmine\event\Listener;
use pocketmine\player\Player;


class CommandListener implements Listener
{

	private $main;

	function __construct( Manager $main )
	{
		$this->main = $main;
	}
	function onCall( Event $event )
	{
		$command = $event->getMessage();

		if( $command[0] != '/' )
		{
			return;
		}
		$main   = $this->getManager();
		$player = $event->getPlayer();
		$command = trim($command);
		$command = substr($command, 1);
		$command = explode(' ', $command);
		
		$nick   = $player->getName();
		$data   = $main->getProvider();
		$jail   = $data->get($nick);
	   if($jail)
		{
		$time   = $data->getTime($nick);
		$reason = $data->getReason($nick);
		$source = $data->getSource($nick);
		$time   = Declinator::formDate($time);
		$prefix = Manager::SERVER_NAME;
		$link   = Manager::LINK;
		if( in_array($command[0], Manager::BAN_COMMAND_IN_JAIL) )
		{
		$player->sendMessage("§c< §f$prefix §c> Вы находитесь в тюрьме!");
		$player->sendMessage("§c< Причина: §f$reason");
		$player->sendMessage("§c< Время: §f$time");
		$player->sendMessage("§c< Источник: §f$source");
		$player->sendMessage("§c< Обжаловать: §f$link");
		$event->cancel();
		}
		}
	}
	private function getManager( )
	{
		return $this->main;
	}
}