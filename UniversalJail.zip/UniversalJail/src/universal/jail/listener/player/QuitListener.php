<?php namespace universal\jail\listener\player;


use universal\jail\Manager;


use pocketmine\event\player\PlayerQuitEvent as Event;
use pocketmine\event\Listener;


class QuitListener implements Listener
{
	/**
	 * @var Manager
	 */
	private $main;


	/**
	 * @param Manager $main
	 */
	function __construct( Manager $main )
	{
		$this->main = $main;
	}


	function onCall( Event $event )
	{
		$main   = $this->getManager();
		$player = $event->getPlayer();
		$pos    = $main->getLastPosition($player->getName(), true);

		if( !isset($pos) )
		{
			return;
		}

		$main->teleport($player, $pos);
	}


	/**
	 * @return Manager
	 */
	private function getManager( )
	{
		return $this->main;
	}
}