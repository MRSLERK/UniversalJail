<?php namespace universal\jail\listener\player;


use universal\jail\Manager;
use universal\jail\util\Declinator;


use pocketmine\event\player\PlayerJoinEvent as Event;
use pocketmine\event\Listener;


class JoinListener implements Listener
{

	function onCall( Event $event )
	{
		$main = Manager::getInstance();

		$player = $event->getPlayer();
		$nick   = $player->getName();
		$data   = $main->getProvider();
		$jail   = $data->get($nick);
	   if($jail)
		{
		$time   = $data->getTime($nick);
		$reason = $data->getReason($nick);
		$source = $data->getSource($nick);
		$time   = Declinator::formDate($time);
		$pos    = $main->getJailPosition();

		$main->setLastPosition($player->getName(), $player->getPosition());
		$main->teleport($player, $pos);
		$prefix = Manager::SERVER_NAME;
		$link   = Manager::LINK;
		$player->sendMessage("§c< §f$prefix §c> Вы находитесь в тюрьме!");
		$player->sendMessage("§c< Причина: §f$reason");
		$player->sendMessage("§c< Время: §f$time");
		$player->sendMessage("§c< Источник: §f$source");
		$player->sendMessage("§c< Обжаловать: §f$link");
		}
		return true;
	}
}