<?php namespace universal\jail\listener\block;


use universal\jail\Manager;


use pocketmine\event\block\BlockBreakEvent as Event;
use pocketmine\event\Listener;


class BreakListener implements Listener
{
	/**
	 * @var Manager
	 */
	private $main;


	/**
	 * @param Manager $main
	 */
	function __construct( Manager $main )
	{
		$this->main = $main;
	}



	function onCall( Event $event )
	{
	    $main   = $this->getManager();
	    $player = $event->getPlayer();
		$nick   = $player->getName();
		$data   = $main->getProvider();
		$jail   = $data->get($nick);
		
	   if($jail)
		{
		$event->cancel();
		}
	}
	
	private function getManager( )
	{
		return $this->main;
	}
}